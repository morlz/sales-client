import api from '@/api'

const state = {
	fileUploadUrl: ""
}

const actions = {

}

const mutations = {

}

const getters = {
	fileUploadUrl ({ fileUploadUrl }) {
		return fileUploadUrl
	}
}

export default {
	state,
	actions,
	mutations,
	getters
}
