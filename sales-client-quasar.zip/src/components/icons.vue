<template>
	<div></div>
</template>
<script>export default {}</script>
<style lang="less">

.el-icon-* {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
}

.icon {
    width: 24px;
    height: 24px;
    background-position: center;
    background-size: contain;
}

.el-icon-list {
    .icon;
    background-image: url("../assets/list.svg");
}

.el-icon-clients {
    .icon;
    background-image: url("../assets/businesswoman.svg");
}

.el-icon-home {
    .icon;
    background-image: url("../assets/house-black-silhouette-without-door.svg");
}

.el-icon-preorder {
    .icon;
    background-image: url("../assets/people-trading.svg");
}

.el-icon-furniture {
    .icon;
    background-image: url("../assets/armchair.svg");
}

.el-icon-salon {
    .icon;
    background-image: url("../assets/shop.svg");
}

.el-icon-storage {
    .icon;
    background-image: url("../assets/warehouse.svg");
}

.el-icon-discount {
    .icon;
    background-image: url("../assets/percent.svg");
}

.el-icon-docs {
    .icon;
    background-image: url("../assets/docs.svg");
}

.el-icon-order {
    .icon;
    background-image: url("../assets/notebook.svg");
}

.el-icon-movement {
    .icon;
    background-image: url("../assets/delivery-packages-on-a-trolley.svg");
}

.el-icon-shipments {
    .icon;
    background-image: url("../assets/delivery-truck.svg");
}

.el-icon-code {
    .icon;
    background-image: url("../assets/code.svg");
}

.el-icon-report {
    .icon;
    background-image: url("../assets/teacher-asking-a-student-about-bad-test-result.svg");
}

.el-icon-sell-result {
    .icon;
    background-image: url("../assets/education-chart.svg");
}

.el-icon-roles {
    .icon;
    background-image: url("../assets/board-games-with-roles.svg");
}

.el-icon-admin {
    .icon;
    background-image: url("../assets/admin-with-cogwheels.svg");
}

.el-icon-personal {
    .icon;
    background-image: url("../assets/group.svg");
}

.el-icon-order-poduction {
    .icon;
    background-image: url("../assets/industrial-robot.svg");
}

</style>
