<template>
	<div class="mainWrapper">
		главная...
	</div>
</template>

<script>
export default {

}
</script>

<style lang="less"></style>
