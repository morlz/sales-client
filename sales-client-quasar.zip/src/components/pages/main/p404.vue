<template>
<div class="page404">
	<el-card class="box-card">
		<div slot="header" class="clearfix">
			<span>Ошибка! Страница не найдена</span>
		</div>
		<div class="content">
			Ошибка 404. Страница удалена или ещё не создана.
		</div>
	</el-card>
</div>
</template>



<script>
export default {}
</script>

<style lang="less"></style>
