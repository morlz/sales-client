<template>
 	<div class="mainWrapper">

	</div>
</template>

<script>

// эта страница "обратная свзяь" из старой версии


export default {
  name: 'HelloWorld',
  data() {
    return {}
  },
};
</script>


<style scoped>

</style>
