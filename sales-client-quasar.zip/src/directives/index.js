import Vue from 'vue'

import GridArea from './GridArea'

Vue.directive('ga', GridArea)
